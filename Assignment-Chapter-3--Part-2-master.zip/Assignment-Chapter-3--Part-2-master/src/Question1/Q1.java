/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Question1;

/**
 *
 * @author ENG.WESAM H ASHOUR
 */
import java.util.Scanner;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

/**
 *
 * @author ENG.WESAM H ASHOUR
 */
public class Q1 {

    public static void main(String[] args) {

        //Q a
        Scanner Q1 = new Scanner(System.in);
        Consumer<Integer> accept = value
                -> System.out.printf("%10d", value);
        System.out.print("Enter INT value !");
        int intgerInput = Q1.nextInt();
        accept.accept(intgerInput);
        //Q b
        Scanner Q2 = new Scanner(System.in);
        Function<String, String> text = String::toUpperCase;
        System.out.print("Enter new text:");
        String textInput = Q2.nextLine();
        System.out.println(text.apply(textInput));
        //Q c
        Scanner Q3 = new Scanner(System.in);
        Supplier<String> print = ()
                -> "Welcome to lambdas!";
        System.out.println(print.get());
        //Q d
        UnaryOperator<Integer> cube_arg = newnumber
                -> newnumber * newnumber * newnumber;
        System.out.print("Enter INT value !");
        int InputCube = Q3.nextInt();
        System.out.println(cube_arg.apply(InputCube));
    }
}
