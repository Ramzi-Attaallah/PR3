/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Question2;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

/**
 *
 * @author ENG.WESAM H ASHOUR
 */
public class Count_chr {

    public static void main(String[] args) throws IOException {
        Map<Character, Integer> chr = new TreeMap<Character, Integer>();
        Scanner scanner = null;

        try {
            scanner = new Scanner(new File("C:/text.txt"));

            while (scanner.hasNext()) {
                char[] line = scanner.nextLine().toLowerCase().toCharArray();

                for (Character character : line) {
                    if (Character.isLetter(character)) {
                        if (chr.containsKey(character)) {
                            chr.put(character, chr.get(character) + 1);
                        } else {
                            chr.put(character, 1);
                        }
                    }
                }
            }
        } finally {
            if (scanner != null) {
                scanner.close();
            }
        }

        if (!chr.isEmpty()) {
            for (Map.Entry<Character, Integer> entry : chr.entrySet()) {
                System.out.println(entry.getKey() + " : " + entry.getValue());
            }
        }
    }
}
