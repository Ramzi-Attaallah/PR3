/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Question4;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 *
 * @author ENG.WESAM H ASHOUR
 */
public class MD_5 {
    public static String hash(String pass) {

        String Hash = pass;
        String generatePASS = null;
        try {
            MessageDigest md = MessageDigest.getInstance("MD_5");
            md.update(Hash.getBytes());
            byte[] bytes = md.digest();
            StringBuilder BB = new StringBuilder();
            for (int i = 0; i < bytes.length; i++) {
                BB.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            generatePASS = BB.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return generatePASS;
    }
}

