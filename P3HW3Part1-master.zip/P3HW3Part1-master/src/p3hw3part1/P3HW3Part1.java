package p3hw3part1;

public class P3HW3Part1 {

    public static void main(String[] args) {
        /*
        for the questions see the classes in this project :)
        Q1 = Question 1
        Q2 = Question 2
        Q3 = Question 3
        */
    }
}
